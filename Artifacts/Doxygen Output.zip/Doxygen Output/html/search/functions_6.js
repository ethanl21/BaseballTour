var searchData=
[
  ['removesouvenir_100',['removeSouvenir',['../classdb_manager.html#ab109bbe9cb4531041f92dfd0ba376c69',1,'dbManager']]]
];
