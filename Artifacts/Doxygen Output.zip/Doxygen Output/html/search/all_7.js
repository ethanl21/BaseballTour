var searchData=
[
  ['logindialog_34',['logindialog',['../classlogindialog.html',1,'']]]
];
