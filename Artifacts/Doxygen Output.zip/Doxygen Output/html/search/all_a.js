var searchData=
[
  ['removesouvenir_40',['removeSouvenir',['../classdb_manager.html#ab109bbe9cb4531041f92dfd0ba376c69',1,'dbManager']]]
];
