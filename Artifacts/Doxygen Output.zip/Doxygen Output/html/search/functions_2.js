var searchData=
[
  ['dbmanager_83',['dbManager',['../classdb_manager.html#a838888f1bcbaa1bb893c76039bc7f631',1,'dbManager']]]
];
