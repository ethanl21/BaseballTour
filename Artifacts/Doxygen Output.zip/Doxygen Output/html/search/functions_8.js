var searchData=
[
  ['updatesouvenir_110',['updateSouvenir',['../classdb_manager.html#acb962cbe360c71f1604c820450e60393',1,'dbManager']]],
  ['updatesouvenirs_111',['updateSouvenirs',['../class_admin.html#aea4a18e9ed1935774c89c3142da0f0b7',1,'Admin']]],
  ['updateteam_112',['updateTeam',['../classdb_manager.html#ab451071f4466425b14b5312382e1d2fb',1,'dbManager']]]
];
