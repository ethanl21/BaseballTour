var searchData=
[
  ['logindialog_69',['logindialog',['../classlogindialog.html',1,'']]]
];
