var searchData=
[
  ['teamdata_51',['teamData',['../structteam_data.html',1,'']]],
  ['tripplanner_52',['tripPlanner',['../classtrip_planner.html',1,'']]]
];
